# OTactile
O'Tactile est une application réaliser lors du 4 projets personnels encadrés en BTS SIO.
C'est application permet de consulter les produits du site web Ô'Tako.
Elle permet aussi de consulter sont profil clients ainsi que c'est commandes.
